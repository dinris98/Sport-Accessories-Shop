import * as React from 'react';
import { Text, View, StyleSheet } from 'react-native';
import Constants from 'expo-constants';

// You can import from local files
import AccessInterface from './components/AccessInterface';
import Login from './components/Login';
import Register from './components/Register';
import UserObject from './components/UserObject';
// or any pure javascript modules available in npm
import { Card } from 'react-native-paper';

/*const readline = require('readline');

const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout

});*/

import { Container, Item, Form, Input, Button, Label } from 'native-base';

export default function App() {
  return (
    <View style={styles.container}>
      <Text style={styles.paragraph}>The Interface Elements</Text>

      <Card>
        <AccessInterface />
      </Card>

      <br />

      <Card>
        <Login />
      </Card>

      <br />

      <Card>
        <Register />
      </Card>
      <br />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    paddingTop: Constants.statusBarHeight,
    backgroundColor: '#ecf0f1',
    padding: 8,
  },
  paragraph: {
    margin: 24,
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
  },
});
