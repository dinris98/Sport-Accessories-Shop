const firebaseConfig = {
  apiKey: "AIzaSyDDHxawoI9UaLI9oZJ_Xzg7X8rjrKouW2Q",
  authDomain: "sport-accessories.firebaseapp.com",
  projectId: "sport-accessories",
  storageBucket: "sport-accessories.appspot.com",
  messagingSenderId: "394637301056",
  appId: "1:394637301056:web:3fc0452cdd4abc881616a5",
  measurementId: "G-8C0WTP4JC1"
};

let NameInputValue = '';
let PasswordInputValue = '';
let EmailInputValue = '';



class UserObject {

  constructor(){
    this.NameInputValue = NameInputValue;
    this.PasswordInputValue = PasswordInputValue;
    this.EmailInputValue = EmailInputValue;
  }

  set NameInputValue(NameInputValue){ this.NameInputValue}
  get NameInputValue(){return this.NameInputValue}

  set PasswordInputValue(PasswordInputValue){ this.PasswordInputValue}
  get PasswordInputValue(){return this.PasswordInputValue}

  set EmailInputValue(EmailInputValue){ this.EmailInputValue}
  get EmailInputValue(){return this.EmailInputValue}
  
  handleBtnClick() {
    this.setState({
      outputPasswordInputValue: this.state.PasswordInputValue,
      outputEmailInputValue: this.state.EmailInputValue,
    });
  }

  handlePasswordInputValueChange(e) {
    this.setState({
      PasswordInputValue: e.target.value,
    });
  }

  handleEmailInputValueChange(e) {
    this.setState({
      EmailInputValue: e.target.value,
    });
  }
}


module.exports= UserObject, firebaseConfig;