import * as React from 'react';
import { Text, View, StyleSheet, Fragment } from 'react-native';
import { Container, Item, Form, Input, Button, Label, UserOutlined } from 'native-base';
import { dist, css } from 'antd';

import AccessInterface from './AccessInterface';
import Register from './Register';
import UserObject from './UserObject';

export default class Login extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      PasswordInputValue: '',
      EmailInputValue: '',
    };
  }
      /*
      <View>
        <Fragment style={styles.container}>
          <h2>Login Interface</h2>
          <div style={styles.main}>
            <Input
              style={styles.PasswordInputValue}
              placeholder="Password"
              prefix={<UserOutlined />}
              value={this.state.PasswordInputValue}
              onChange={this.handlePasswordInputValueChange.bind(this)}
            />

            <Input
              style={styles.EmailInputValue}
              placeholder="Email"
              value={this.state.EmailInputValue}
              onChange={this.handleEmailInputValueChange.bind(this)}
            />

            <Button
              type="primary"
              onClick={this.UserObject.handleBtnClick.bind(this)}>
              Submit
            </Button>
          </div>
        </Fragment>
      </View>
      
  
      */
      

  render() {
    return (
      <Container>

        <Form>
          <Item floatingCapitalizeLabel>
            <Label>Email</Label>
            <Input autoCapitalize="#" autoCorrect={false}  onPress={this.state.EmailInputValue}
            />
          </Item>

          <Item floatingCapitalizeLabel>
            <Label>Password</Label>
              <Input
              secureTextEntry={true}
              autoCapitalize="#"
              autoCorrect={false}
              onPress={this.state.PasswordInputValue}
            />
          </Item>

          <Button styles = {styles.button} full success>
            <Text>Login</Text>
          </Button>

        </Form>
      </Container>
    );
  }
}

const styles = StyleSheet.create({
button : {
Color : "#841584"
},
});
