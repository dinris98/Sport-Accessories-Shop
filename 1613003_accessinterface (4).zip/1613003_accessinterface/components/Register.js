import * as React from 'react';
import { Text, View, StyleSheet, Image,Fragment } from 'react-native';
// You can import from local files
import AccessInterface from './AccessInterface';
import Login from './Login';
import UserObject from './UserObject';
import { Container, Item, Form, Input, Button, Label } from 'native-base';

export default class Register extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      NameInputValue: '',
      PasswordInputValue: '',
      EmailInputValue: '',
    };
  }

  /* render() {
    return <Fragment> </Fragment>;
  } */

  /*render() {
    return (
      <View>
        <Fragment style={styles.container}>
          <h2>Login Interface</h2>
          <div style={styles.main}>
            <Input
              style={styles.PasswordInputValue}
              placeholder="Password"
              prefix={<UserOutlined />}
              value={this.state.PasswordInputValue}
              onChange={this.handlePasswordInputValueChange.bind(this)}
            />

            <Input
              style={styles.EmailInputValue}
              placeholder="Email"
              value={this.state.EmailInputValue}
              onChange={this.handleEmailInputValueChange.bind(this)}
            />

            <Button
              type="primary"
              onClick={this.UserObject.handleBtnClick.bind(this)}>
              Submit
            </Button>
          </div>
        </Fragment>
      </View>
    );
  }*/

  render() {
    return (
      <Container>
        <Form>
          <Item floatingCapitalizeLabel>
            <Label>Name</Label>
            <Input autoCapitalize="none" autoCorrect={false} onPress={this.state.NameInputValue}/>
          </Item>
          <Item floatingCapitalizeLabel>
            <Label>Email</Label>
            <Input autoCapitalize="none" autoCorrect={false} onPress={this.state.EmailInputValue}/>
          </Item>
          <Item floatingCapitalizeLabel>
            <Label>Password</Label>
            <Input
              secureTextEntry={true}
              autoCapitalize="none"
              autoCorrect={false}
              onPress={this.state.PasswordInputValue}
            />
          </Item>
          <Button styles = {styles.button} full success>
            <Text>Register</Text>
          </Button>
        </Form>
      </Container>
    );
  }
}

const styles = StyleSheet.create({
button : {
Color : "#841584"
},
});